sm = stan_model("TPI.stan", model_name = "tpi", allow_undefined = TRUE,
                includes = paste0('\n#include "',
                                  file.path(getwd(), 'get_iter.hpp'), '"\n'))

sf = sampling(sm,iter = 100, chains = 1,
              data = list(N = 100,
                          id = 2,
                          y = rbind(rnorm(100),1+rnorm(100))),
              sample_file = "tmp2.csv")


mc = "
data {
  int<lower=0> J; // number of schools 
real y[J]; // estimated treatment effects
real<lower=0> sigma[J]; // s.e. of effect estimates 
}
parameters {
real mu; 
real<lower=0> tau;
real eta[J];
}
transformed parameters {
real theta[J];
for (j in 1:J)
theta[j] = mu + tau * eta[j];
}
model {
target += normal_lpdf(eta | 0, 1);
target += normal_lpdf(y | theta, sigma);
}
"