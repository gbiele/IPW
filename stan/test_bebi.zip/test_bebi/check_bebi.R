library(boot)
library(VGAM)
library(rstan)
library(loo)
library(HDInterval)
options(mc.cores = 4)

set.seed(1234)

N = 100
K = 4
phi = 50
X = matrix(rnorm(N*K),ncol = K)
b = matrix(rnorm(K),ncol = 1)/2
p = inv.logit(-.8 + X %*% b)
Y = rbetabinom.ab(N,size = 22, shape1 = p*phi, shape2 = (1-p)*phi)
hist(Y,breaks = (0:23)-.5)
standata = list(N = N,
                K = K,
                X = X,
                Y = Y)

#sm_logit_QR = stan_model("bebi_QR_logit.stan")
sm_logit = stan_model("bebi_logit.stan")
sf_logit = sampling(sm_logit,
                    data = standata,
                    iter = 500,
                    seed = 123)

sm_linear = stan_model("bebi_linear.stan")
sf_linear = sampling(sm_linear,
                    data = standata,
                    init = lapply(1:4, function(x) list(b = rep(0,4))),
                    iter = 500,
                    seed = 123)

b_hdis = hdi(extract(sf_logit,"b")$b,
             credMass = .90)
plot(0, type = "n",
     ylim = c(range(b_hdis)),
     xlim = c(1,4),
     xaxt = "n",ylab = "", xlab = "")
axis(1,1:4)
segments(x0 = 1:4,
         y0 = b_hdis[1,],
         y1 = b_hdis[,2])
points(1:4,b, pch = 16, size  = 2, col = "green4")

loo(extract_log_lik(sf_logit))
loo(extract_log_lik(sf_linear))

p_logit = X %*% b
p_rep_logit = logit(extract(sf_logit,"p")$p)
p_rep_linear = logit(extract(sf_linear,"p")$p)
lims = max(abs(p_logit))*c(-1,1)
par(mfrow = c(2,1))
plot(p_logit,colMeans(p_rep_logit),ylim = lims, xlim = lims, col = adjustcolor("red",alpha = .25),pch = 16)
points(p_logit,colMeans(p_rep_linear),col = adjustcolor("blue",alpha = .25),pch = 16)
for (k in 1:50) {
  abline(lm(p_rep_logit[k,]~p_logit),col = adjustcolor("red",alpha = .1))
  abline(lm(p_rep_linear[k,]~p_logit),col = adjustcolor("blue",alpha = .1))
}
plot(density(cor(p_logit,t(p_rep_logit))),col = "red")
lines(density(cor(p_logit,t(p_rep_linear))),col = "blue")


