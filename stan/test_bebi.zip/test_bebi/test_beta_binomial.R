sm_code = 
"
data {
  int N;
  int s;
  int y[N];
}

parameters {
  real<lower = 0, upper = 25> alpha;
  real<lower = 0, upper = 25> beta;
}

model {
  y ~ beta_binomial(s, alpha,beta);
}

generated quantities {
  vector[N] y_rep;
  for(n in 1:N){
   y_rep[n] = beta_binomial_rng(s,alpha,beta); //posterior draws to get posterior predictive checks
 }
}
"
sm = stan_model(model_code = sm_code)


sm_code = 
'
data {
  int N; //the number of observations
  int y[N]; //the response
  int W; 
}
parameters {
  real<lower = 0, upper = 1> mu; //the regression parameters
  real<lower = 0, upper = 1> theta; //the overdispersion parameter
}
transformed parameters {
  real alpha; //the first shape parameter for the beta distribution
  real beta; //the second shape parameter for the beta distribution
  real phi;  
  
  phi = (1-theta)/theta;
  alpha = mu * phi;
  beta = (1-mu) * phi;
}
model {  
   y ~ beta_binomial(W,alpha,beta);
}
generated quantities {
 vector[N] y_rep;
 for(n in 1:N){
  y_rep[n] = beta_binomial_rng(W,alpha,beta); //posterior draws to get posterior predictive checks
 }
}'
sm2 = stan_model(model_code = sm_code)