library(rstan)
options(mc.cores = 4)
load("../data/pADHD_2SB/a1_i1.Rdata")
N = 10000
idx = sample(nrow(standata$X),N)
standata$N = N
standata$Y = standata$Y[idx]
standata$X = standata$X[idx,-1]
standata$ipw_idx = standata$ipw_idx[idx]
standata$K = ncol(standata$X)
standata$K_ipw = ncol(standata$X)

Q = qr.Q(qr(standata$X))*N
hist(Q)
print(paste("max(Q)=",max(Q)))


sm = stan_model("bebi_deltaARCC.stan")
sf = sampling(sm,data = standata,
              chains = 4,
              iter = 2000,
              warmup = 500,
              init = list(list(b_tilde_ipw = rep(1e-4,13),
                               b_tilde_AR = rep(1e-4,13)),
                          list(b_tilde_ipw = rep(1e-4,13),
                               b_tilde_AR = rep(1e-4,13)),
                          list(b_tilde_ipw = rep(1e-4,13),
                               b_tilde_AR = rep(1e-4,13)),
                          list(b_tilde_ipw = rep(1e-4,13),
                               b_tilde_AR = rep(1e-4,13))
                          )
              )


standata$scaleQ = 1
sf1 = sampling(sm,data = standata,
                chains = 1,
                iter = 1000,
                warmup = 500,
                init = list(list(b_tilde_ipw = rep(1e-4,13))),
                pars = c("b_tilde_ipw","alpha_ipw"),
                control = list(adapt_delta = .9),
                seed = 123
)
standata$scaleQ = 10
sf10 = sampling(sm,data = standata,
              chains = 1,
              iter = 1000,
              warmup = 500,
              init = list(list(b_tilde_ipw = rep(1e-4,13))),
              pars = c("b_tilde_ipw","alpha_ipw"),
              control = list(adapt_delta = .9),
              seed = 123
)
standata$scaleQ = 100
sf100 = sampling(sm,data = standata,
              chains = 1,
              iter = 1000,
              warmup = 500,
              init = list(list(b_tilde_ipw = rep(1e-4,13))),
              pars = c("b_tilde_ipw","alpha_ipw"),
              control = list(adapt_delta = .9),
              seed = 123
)
standata$scaleQ = 10000
sf10000 = sampling(sm,data = standata,
                 chains = 1,
                 iter = 1000,
                 warmup = 500,
                 init = list(list(b_tilde_ipw = rep(1e-4,13))),
                 pars = c("b_tilde_ipw","alpha_ipw"),
                 control = list(adapt_delta = .9),
                 seed = 123
)
standata$scaleQ = 10000
sf10000 = sampling(sm,data = standata,
                   chains = 1,
                   iter = 1000,
                   warmup = 500,
                   init = list(list(b_tilde_ipw = rep(1e-4,13))),
                   pars = c("b_tilde_ipw","alpha_ipw"),
                   control = list(adapt_delta = .9),
                   seed = 123
)
